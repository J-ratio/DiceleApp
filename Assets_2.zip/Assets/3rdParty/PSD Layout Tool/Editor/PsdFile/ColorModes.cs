﻿namespace PhotoshopFile
{
    /// <summary>
    /// Enumeration for the different types of color modes
    /// </summary>
    public enum ColorModes
    {
        /// <summary>
        /// Grayscale color.
        /// </summary>
        Grayscale = 1,

        /// <summary>
        /// Indexed color.
        /// </summary>
        Indexed = 2,

        /// <summary>
        /// Red, Green, Blue color.
        /// </summary>
        RGB = 3,

        /// <summary>
        /// CMYK color.
        /// </summary>
        CMYK = 4,

        /// <summary>
        /// Multichannel color.
        /// </summary>
        Multichannel = 7,

        /// <summary>
        /// Duotone color.
        /// </summary>
        Duotone = 8,

        /// <summary>
        /// Lab color.
        /// </summary>
        Lab = 9,
    }
}
