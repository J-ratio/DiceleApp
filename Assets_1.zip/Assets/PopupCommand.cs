using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PopupCommand : IPopupCommand
{
    private Animator anime;

    public bool IsFinished { get => throw new System.NotImplementedException(); set => throw new System.NotImplementedException(); }

    public void Execute()
    {
        throw new System.NotImplementedException();
    }
}
