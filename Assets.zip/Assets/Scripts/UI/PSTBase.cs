using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PSTBase : MonoBehaviour
{
    internal bool Clicked { get; set; }

}
