﻿public interface IPopupCommand
{
    bool IsFinished { get; set; }

    void Execute();
}